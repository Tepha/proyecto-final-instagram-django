## aqui podemos configurar variables globales
from django.apps import AppConfig

# configuración del modulo
class PostsConfig(AppConfig):
    # post application settings
    name = 'posts'
    verbose_name = 'Posts'
