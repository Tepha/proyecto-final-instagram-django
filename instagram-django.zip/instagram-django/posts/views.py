from django.shortcuts import render
from datetime import datetime

posts = [
    {
        'title': 'Mont Blanc',
        'user': {
            'name': 'Yésica Cortés',
            'picture': 'https://picsum.photos/60/60/?image=1027'
        },
        'timestamp': datetime.now().strftime('%b %dth, %Y - %H:%M hrs'),
        'photo': 'https://picsum.photos/800/600?image=1036',
    },
    {
        'title': 'Via Láctea',
        'user': {
            'name': 'Christian Van der Henst',
            'picture': 'https://picsum.photos/60/60/?image=1005'
        },
        'timestamp': datetime.now().strftime('%b %dth, %Y - %H:%M hrs'),
        'photo': 'https://picsum.photos/800/800/?image=903',
    },
    {
        'title': 'Nuevo auditorio',
        'user': {
            'name': 'Uriel (thespianartist)',
            'picture': 'https://picsum.photos/60/60/?image=883'
        },
        'timestamp': datetime.now().strftime('%b %dth, %Y - %H:%M hrs'),
        'photo': 'https://picsum.photos/500/700/?image=1076',
    }
]

# users = [
#     {
#         'email': 'cvander@sornygram.com',
#         'first_name': 'Christian',
#         'last_name': 'Van der Henst',
#         'password': '1234567',
#         'is_admin': True
#     },
#     {
#         'email': 'freddier@sornygram.com',
#         'first_name': 'Freddy',
#         'last_name': 'Vega',
#         'password': '987654321'
#     },
#     {
#         'email': 'yesica@sornygram.com',
#         'first_name': 'Yésica',
#         'last_name': 'Cortés',
#         'password': 'qwerty',
#         'birthdate': date(1990, 12,19)
#     },
#     {
#         'email': 'arturo@sornygram.com',
#         'first_name': 'Arturo',
#         'last_name': 'Martínez',
#         'password': 'msicomputer',
#         'is_admin': True,
#         'birthdate': date(1981, 11, 6),
#         'bio': "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
#     }
# ]

# CREAR USUARIOS A PARTIR DE USERS
# from posts.models import User
#
# for user inusers:
#     obj = User(**user)
#     obj.save()
#     print(obj.pk, ':', obj.email)

def list_posts(request):
    # renderiza la vista seleccionada y le envia "posts"
    return render(request, 'posts/feed.html', {'posts': posts})
