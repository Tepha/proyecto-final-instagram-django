from django.urls import path
from django.contrib import admin

# importa los archivos de configuración
from django.conf import settings
from django.conf.urls.static import static

# importa las vistas de nuestros módulos
from sornygram import views as local_views
from posts import views as posts_views
from users import views as users_views

# urls del módulo
urlpatterns = [
    # admin panel
    path('admin/', admin.site.urls),
    # routes locales (django testing)
    path('hello', local_views.greeting, name='greeting'),
    path('sorted', local_views.sort_numbers, name='sort'),
    path('hi/<str:name>/<int:age>/', local_views.hi, name='hi'),
    # routes del módulo "posts"
    path('posts/', posts_views.list_posts, name='feed'),
    # routes del módulo "users"
    path('users/login', users_views.login_view, name='login'),
    path('users/logout', users_views.logout_view, name='logout'),
    path('users/signup', users_views.signup_view, name='signup')
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
