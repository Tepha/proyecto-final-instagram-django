from django.http import HttpResponse
from datetime import datetime
import json

# hola mundo junto al horario formateado
def greeting(request):
    return HttpResponse('hello_world! {actual_date}'.format(
        actual_date=datetime.now().strftime('%b %dth, %Y - %H:%M hrs')
    ))

# recibir números y devolver json ordenado
def sort_numbers(request):
    # sacamos los números del url y los transformamos en array
    numbers = [int(i) for i in request.GET['numbers'].split(',')]
    # ordenamos los números
    sorted_numbers = sorted(numbers)
    # creamos un json con los números ordenados
    data = {
        'status' : '200',
        'numbers' : sorted_numbers,
        'message' : 'Numbers sorted correctly'
    }
    # retornamos el json creado
    return HttpResponse(
        json.dumps(data),
        content_type='application/json',
    )

# recibe un nombre y una edad en la url
def hi(request, name, age):
    if age>=13:
        message = 'Hello {}! Welcome to Sornygram'.format(name)
    else:
        message = 'Sorry {}, you are not allowed here'.format(name)
    return HttpResponse(message)
